// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>



// Custom Exception Class
class CustomException : public std::exception {
public:
    explicit CustomException(const char* message) : msg(message) {}
    const char* what() const noexcept override {
        return msg;
    }
private:
    const char* msg;
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Standard exception occurred in do_even_more_custom_application_logic.");


    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    // Catching std::exception
    catch (const std::exception& e) {
        std::cerr << "Error in do_custom_application_logic: " << e.what() << std::endl;
    
    
    }


    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    throw CustomException("Custom exception thrown in do_custom_application_logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0) {
        throw std::logic_error("Division by 0!"); //Throw a logic error if division by zero occurs
    }
    return (num / den); // Return the result of the division if no error
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try {

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::logic_error& e) {
        // Catching only divide by zero errors
        std::cerr << "Math Error: " << e.what() << std::endl;
    
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    

    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e) {  // Catching custom exceptions
        std::cerr << "Custom Exception Caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e) {  // Catching standard exceptions
        std::cerr << "Standard Exception Caught: " << e.what() << std::endl;
    }
    catch (...) {  // Catch-all for any uncaught exceptions
        std::cerr << "An unknown error occurred." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu